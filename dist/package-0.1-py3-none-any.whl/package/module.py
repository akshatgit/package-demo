class Module(object):
    def __init__(self):
        super().__init__()
    def greeting(self):
        return "Hello World"
    pass