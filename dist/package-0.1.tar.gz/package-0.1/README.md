# Python Package Example

## Structure

```shell
/project/
    /package/
        __init__.py
        module.py
    setup.py
```

## Requirements

```shell
python3.7 -m pip install --user --upgrade setuptools wheel
```

## Build

```shell
python3.7 setup.py sdist bdist_wheel
```

## Testing

Activate Virtualenv:

```shell
source venv/bin/activate
```

Install Wheel Package:

```shell
pip install dist/PackageDemo-0.1-py3-none-any.whl
```

```shell
(venv) ➜ pip3.7 freeze | grep -i demo
PackageDemo==0.1
```

**Note: Change package version accordingly.
